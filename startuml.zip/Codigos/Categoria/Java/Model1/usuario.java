
import java.util.*;

/**
 * 
 */
public class usuario {

    /**
     * Default constructor
     */
    public usuario() {
    }


    /**
     * 
     */
    public void validar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void visualizar_usuario() {
        // TODO implement here
    }

    /**
     * 
     */
    public void modificar_usuario() {
        // TODO implement here
    }

}