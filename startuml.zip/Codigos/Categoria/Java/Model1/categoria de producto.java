
import java.util.*;

/**
 * 
 */
public class categoria de producto {

    /**
     * Default constructor
     */
    public categoria de producto() {
    }


    /**
     * 
     */
    public void numeros de categoria() {
        // TODO implement here
    }

    /**
     * 
     */
    public void eliminar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void preparar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void registrar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void modificar() {
        // TODO implement here
    }

}