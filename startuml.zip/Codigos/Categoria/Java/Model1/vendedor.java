
import java.util.*;

/**
 * 
 */
public class vendedor {

    /**
     * Default constructor
     */
    public vendedor() {
    }


    /**
     * 
     */
    public void visualizar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void modificar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void obtener_NumVendedro() {
        // TODO implement here
    }

}