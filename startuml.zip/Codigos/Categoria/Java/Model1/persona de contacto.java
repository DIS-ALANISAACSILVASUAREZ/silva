
import java.util.*;

/**
 * 
 */
public class persona de contacto {

    /**
     * Default constructor
     */
    public persona de contacto() {
    }


    /**
     * 
     */
    public void visualizar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void bajar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void listar() {
        // TODO implement here
    }

}