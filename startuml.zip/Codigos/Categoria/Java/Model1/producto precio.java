
import java.util.*;

/**
 * 
 */
public class producto precio {

    /**
     * Default constructor
     */
    public producto precio() {
    }

    /**
     * 
     */
    public void cantidad() {
        // TODO implement here
    }

    /**
     * 
     */
    public void validar() {
        // TODO implement here
    }

}