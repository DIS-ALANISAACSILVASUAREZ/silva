#!/usr/bin/python
#-*- coding: utf-8 -*-

class pedido:
    def __init__(self):

    def registrar(self, ):
        pass

    def obtener_numPedido(self, ):
        pass

