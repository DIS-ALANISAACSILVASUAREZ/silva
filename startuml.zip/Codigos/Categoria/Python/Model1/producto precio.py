#!/usr/bin/python
#-*- coding: utf-8 -*-

class producto precio:
    def __init__(self):
        pass

    def cantidad(self, ):
        pass

    def validar(self, ):
        pass

