#!/usr/bin/python
#-*- coding: utf-8 -*-

class persona de contacto:
    def __init__(self):

    def visualizar(self, ):
        pass

    def bajar(self, ):
        pass

    def listar(self, ):
        pass

