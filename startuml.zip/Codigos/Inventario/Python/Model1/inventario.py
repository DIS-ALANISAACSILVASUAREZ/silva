#!/usr/bin/python
#-*- coding: utf-8 -*-

class inventario:
    def __init__(self):
        self.registra = None
        self.consulta = None
        self.modifica = None
        self.desincorpora o incorpora = None
        self.mantenimiento = None
        self.identificar y autentificar = None

    def genera reporte de pago(self, ):
        pass

