#!/usr/bin/python
#-*- coding: utf-8 -*-

class cliente:
    def __init__(self):

    def consulta(self, ):
        pass

    def genera reporte de pago(self, ):
        pass

