
import java.util.*;

/**
 * 
 */
public class inventario {

    /**
     * Default constructor
     */
    public inventario() {
    }

    /**
     * 
     */
    public void registra;

    /**
     * 
     */
    public void consulta;

    /**
     * 
     */
    public void modifica;

    /**
     * 
     */
    public void desincorpora o incorpora;

    /**
     * 
     */
    public void mantenimiento;

    /**
     * 
     */
    public void identificar y autentificar;


    /**
     * 
     */
    public void genera reporte de pago() {
        // TODO implement here
    }

}