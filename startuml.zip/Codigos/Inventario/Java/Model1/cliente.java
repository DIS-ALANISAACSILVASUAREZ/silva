
import java.util.*;

/**
 * 
 */
public class cliente {

    /**
     * Default constructor
     */
    public cliente() {
    }


    /**
     * 
     */
    public void consulta() {
        // TODO implement here
    }

    /**
     * 
     */
    public void genera reporte de pago() {
        // TODO implement here
    }

}