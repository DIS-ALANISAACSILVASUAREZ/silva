#!/usr/bin/python
#-*- coding: utf-8 -*-

class salida:
    def __init__(self):
        self.id_salida = None
        self.cantidad = None
        self.valor_unidad = None
        self.fecha = None
        self.id_articulo = None

    def ingresar(self, ):
        pass

    def modificar(self, ):
        pass

    def consultar(self, ):
        pass

    def eliminar(self, ):
        pass

    def validar_codigo(self, ):
        pass

