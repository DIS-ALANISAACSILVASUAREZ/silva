
import java.util.*;

/**
 * 
 */
public class salida {

    /**
     * Default constructor
     */
    public salida() {
    }

    /**
     * 
     */
    public void id_salida;

    /**
     * 
     */
    public void cantidad;

    /**
     * 
     */
    public void valor_unidad;

    /**
     * 
     */
    public void fecha;

    /**
     * 
     */
    public void id_articulo;


    /**
     * 
     */
    public void ingresar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void modificar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void consultar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void eliminar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void validar_codigo() {
        // TODO implement here
    }

}