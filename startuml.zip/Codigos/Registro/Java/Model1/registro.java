
import java.util.*;

/**
 * 
 */
public class registro {

    /**
     * Default constructor
     */
    public registro() {
    }

    /**
     * 
     */
    public void crear_cuenta;

    /**
     * 
     */
    public void datos;

    /**
     * 
     */
    public void actualizar datos;

    /**
     * 
     */
    public void finalizar registro;

    /**
     * 
     */
    public void usuario_contraseña;


    /**
     * 
     */
    public void verificar usuario() {
        // TODO implement here
    }

    /**
     * 
     */
    public void permisos() {
        // TODO implement here
    }

}