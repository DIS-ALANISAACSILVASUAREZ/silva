
import java.util.*;

/**
 * 
 */
public class usuario {

    /**
     * Default constructor
     */
    public usuario() {
    }

    /**
     * 
     */
    public void nombre;

    /**
     * 
     */
    public void direccion;

    /**
     * 
     */
    public void telefono;

    /**
     * 
     */
    public void email;

    /**
     * 
     */
    public void codigo_postal;

}