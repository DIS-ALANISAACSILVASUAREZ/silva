#!/usr/bin/python
#-*- coding: utf-8 -*-

class registro:
    def __init__(self):
        self.crear_cuenta = None
        self.datos = None
        self.actualizar datos = None
        self.finalizar registro = None
        self.usuario_contraseña = None

    def verificar usuario(self, ):
        pass

    def permisos(self, ):
        pass

