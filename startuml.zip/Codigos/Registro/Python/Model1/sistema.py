#!/usr/bin/python
#-*- coding: utf-8 -*-

class sistema:
    def __init__(self):

    def verificar_datos(self, ):
        pass

    def acceso_cuenta(self, ):
        pass

