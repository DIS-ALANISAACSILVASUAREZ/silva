#!/usr/bin/python
#-*- coding: utf-8 -*-

class sistema:
    def __init__(self):

    def actualizar_datos(self, ):
        pass

    def modificar(self, ):
        pass

