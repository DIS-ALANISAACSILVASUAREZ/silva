#!/usr/bin/python
#-*- coding: utf-8 -*-

class personal de mantenimiento:
    def __init__(self):
        self.cuenta = None
        self.registra = None
        self.elimina = None
        self.buscar = None
        self.stock = None
        self.reportes = None

