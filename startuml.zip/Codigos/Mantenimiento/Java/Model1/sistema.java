
import java.util.*;

/**
 * 
 */
public class sistema {

    /**
     * Default constructor
     */
    public sistema() {
    }


    /**
     * 
     */
    public void actualizar_datos() {
        // TODO implement here
    }

    /**
     * 
     */
    public void modificar() {
        // TODO implement here
    }

}