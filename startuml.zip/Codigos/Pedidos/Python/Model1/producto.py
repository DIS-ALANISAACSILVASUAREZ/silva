#!/usr/bin/python
#-*- coding: utf-8 -*-

class producto:
    def __init__(self):
        self.nombre = None
        self.precio = None
        self.marca = None
        self.stock = None
        self.descripcion = None

    def modificar_stock(self, ):
        pass

