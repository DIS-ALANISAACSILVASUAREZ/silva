
import java.util.*;

/**
 * 
 */
public class pedido compuesto {

    /**
     * Default constructor
     */
    public pedido compuesto() {
    }


    /**
     * 
     */
    public void obtener_total() {
        // TODO implement here
    }

    /**
     * 
     */
    public void añadir() {
        // TODO implement here
    }

    /**
     * 
     */
    public void eliminar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void cobrar() {
        // TODO implement here
    }

}