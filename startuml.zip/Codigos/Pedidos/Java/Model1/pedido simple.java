
import java.util.*;

/**
 * 
 */
public class pedido simple {

    /**
     * Default constructor
     */
    public pedido simple() {
    }

    /**
     * 
     */
    public void obtener_total() {
        // TODO implement here
    }

    /**
     * 
     */
    public void cobrar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void obtener_detalle() {
        // TODO implement here
    }

}