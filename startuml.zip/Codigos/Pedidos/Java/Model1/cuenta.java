
import java.util.*;

/**
 * 
 */
public class cuenta {

    /**
     * Default constructor
     */
    public cuenta() {
    }

    /**
     * 
     */
    public void id_cuenta;

    /**
     * 
     */
    public void disponible;

    /**
     * 
     */
    public void Num_tarjeta;

    /**
     * 
     */
    public void pagar_pedido() {
        // TODO implement here
    }

}