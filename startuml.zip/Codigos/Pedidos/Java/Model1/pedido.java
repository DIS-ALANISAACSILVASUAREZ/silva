
import java.util.*;

/**
 * 
 */
public class pedido {

    /**
     * Default constructor
     */
    public pedido() {
    }

    /**
     * 
     */
    public void total;

    /**
     * 
     */
    public void estado;




    /**
     * 
     */
    public void cobrar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void confirmar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void obtener_total() {
        // TODO implement here
    }

    /**
     * 
     */
    public void obtener_detalle() {
        // TODO implement here
    }

    /**
     * 
     */
    public void añadir_pedido() {
        // TODO implement here
    }

}