#!/usr/bin/python
#-*- coding: utf-8 -*-

class sistema:
    def __init__(self):
        self.datos_usuario = None
        self.actualizar = None
        self.mantenimiento_pagina = None

