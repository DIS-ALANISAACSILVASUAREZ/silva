#!/usr/bin/python
#-*- coding: utf-8 -*-

class usuario:
    def __init__(self):
        self.cuenta = None
        self.direccion = None
        self.stock = None

    def compra(self, ):
        pass

    def seguridad_tarjeta(self, ):
        pass

    def NIP(self, ):
        pass

