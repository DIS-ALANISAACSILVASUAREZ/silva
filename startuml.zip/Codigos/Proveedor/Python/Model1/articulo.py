#!/usr/bin/python
#-*- coding: utf-8 -*-

class articulo:
    def __init__(self):
        self.id_articulo = None
        self.stock = None
        self.nombre = None
        self.marca = None
        self.proveedor = None

    def ingresar(self, ):
        pass

    def adiccionar(self, ):
        pass

    def modificar(self, ):
        pass

    def consultar(self, ):
        pass

    def eliminar(self, ):
        pass

