#!/usr/bin/python
#-*- coding: utf-8 -*-

class cliente:
    def __init__(self):
        self.id_cliente = None
        self.nombre = None
        self.direccion = None
        self.documentos = None
        self.correo = None
        self.telefono = None

    def ingresar(self, ):
        pass

    def consultar(self, ):
        pass

    def modificar(self, ):
        pass

    def eliminar(self, ):
        pass

