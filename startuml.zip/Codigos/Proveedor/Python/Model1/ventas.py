#!/usr/bin/python
#-*- coding: utf-8 -*-

class ventas:
    def __init__(self):
        self.id_venta = None
        self.documentos = None
        self.id_articulo = None
        self.fecha = None
        self.cantidad = None
        self.id_cliente = None

    def ingresar(self, ):
        pass

    def consultar(self, ):
        pass

    def modificar(self, ):
        pass

    def eliminar(self, ):
        pass

    def articulo(self, ):
        pass

