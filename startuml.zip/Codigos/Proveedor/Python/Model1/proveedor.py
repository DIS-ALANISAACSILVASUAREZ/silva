#!/usr/bin/python
#-*- coding: utf-8 -*-

class proveedor:
    def __init__(self):
        self.id_proveedor = None
        self.nombre = None
        self.documentos = None
        self.direccion = None
        self.correo = None
        self.telefono = None

    def modificar(self, ):
        pass

    def consultar(self, ):
        pass

    def eliminar(self, ):
        pass

    def ingresar(self, ):
        pass

