
import java.util.*;

/**
 * 
 */
public class articulo {

    /**
     * Default constructor
     */
    public articulo() {
    }

    /**
     * 
     */
    public void id_articulo;

    /**
     * 
     */
    public void stock;

    /**
     * 
     */
    public void nombre;

    /**
     * 
     */
    public void marca;

    /**
     * 
     */
    public void proveedor;

    /**
     * 
     */
    public void ingresar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void adiccionar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void modificar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void consultar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void eliminar() {
        // TODO implement here
    }

}