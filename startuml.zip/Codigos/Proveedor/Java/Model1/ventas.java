
import java.util.*;

/**
 * 
 */
public class ventas {

    /**
     * Default constructor
     */
    public ventas() {
    }

    /**
     * 
     */
    public void id_venta;

    /**
     * 
     */
    public void documentos;

    /**
     * 
     */
    public void id_articulo;

    /**
     * 
     */
    public void fecha;

    /**
     * 
     */
    public void cantidad;

    /**
     * 
     */
    public void id_cliente;


    /**
     * 
     */
    public void ingresar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void consultar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void modificar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void eliminar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void articulo() {
        // TODO implement here
    }

}