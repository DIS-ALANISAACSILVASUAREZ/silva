
import java.util.*;

/**
 * 
 */
public class cliente {

    /**
     * Default constructor
     */
    public cliente() {
    }

    /**
     * 
     */
    public void id_cliente;

    /**
     * 
     */
    public void nombre;

    /**
     * 
     */
    public void direccion;

    /**
     * 
     */
    public void documentos;

    /**
     * 
     */
    public void correo;

    /**
     * 
     */
    public void telefono;


    /**
     * 
     */
    public void ingresar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void consultar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void modificar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void eliminar() {
        // TODO implement here
    }

}